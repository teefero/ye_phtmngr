<?
echo 'You are uploading a photo ...'
?>