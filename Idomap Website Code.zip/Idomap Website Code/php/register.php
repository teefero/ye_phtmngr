<?
echo 'You are registering ...'
?>